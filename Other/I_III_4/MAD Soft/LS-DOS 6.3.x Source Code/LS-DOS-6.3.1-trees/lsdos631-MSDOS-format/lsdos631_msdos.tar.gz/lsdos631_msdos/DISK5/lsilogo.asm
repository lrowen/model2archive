; LSI "BASIC" LS-DOS Sign-on file 10/22/83
;
	ORG	7*80+CRTBGN$+29
;
	IF	@BLD631
	DB	0BFH			;<631>
	DC	17,083H			;<631>
	DB	0BFH			;<631>
	DS	61			;<631>
	DB	0BFH,'                 ',0BFH	;<631>
	DS	61			;<631>
	DB	0BFH,'  W E L C O M E  ',0BFH	;<631>
	DS	61			;<631>
	DB	0BFH,'                 ',0BFH	;<631>
	DS	61			;<631>
	DB	0BFH,'       t o       ',0BFH	;<631>
	DS	61			;<631>
	DB	0BFH,'                 ',0BFH	;<631>
	DS	61			;<631>
	DB	0BFH,'   L S - D O S   ',0BFH	;<631>
	DS	61			;<631>
	DB	0BFH,'                 ',0BFH	;<631>
	DS	61			;<631>
	DC	19,083H			;<631>
	ELSE
	DB	'*******************'
	DS	61
	DB	'*                 *'
	DS	61
	DB	'*  W E L C O M E  *'
	DS	61
	DB	'*                 *'
	DS	61
	DB	'*       t o       *'
	DS	61
	DB	'*                 *'
	DS	61
	DB	'*   L S - D O S   *'
	DS	61
	DB	'*                 *'
	DS	61
	DB	'*******************'
	ENDIF
