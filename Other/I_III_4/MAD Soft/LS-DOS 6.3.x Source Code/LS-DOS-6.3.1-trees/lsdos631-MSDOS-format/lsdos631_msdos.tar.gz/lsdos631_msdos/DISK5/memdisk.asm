;MEMDISK/ASM - Memory Disk Driver
	TITLE	<MEMDISK/DCT - LS-DOS 6.2>
;
*GET	SVCMAC:3		;SVC Macro equivalents
*GET	VALUES:3		;Misc. equates
*GET	COPYCOM:3		;Copyright message
;
SDBPC	EQU	5*2*256		;Single Density Bytes/Cyl
DDBPC	EQU	6*3*256		;Double Density Bytes/Cyl
LOWEST	EQU	8000H		;Lowest addr for Bank 0
HIDRVR	EQU	1300H		;Highest addr for Driver
BUFFER$	EQU	2300H		;Temporary I/O buffer Add
MINCYL	EQU	3
WP	EQU	15		;Write Prot Disk Error #
;
	IF	@BLD631
	ORG	3000H
	ELSE
	ORG	2C00H
	ENDIF
;
START
	IF	@BLD631
	LD	(EXIT+1),SP	;<631>
	@@CKBRKC		;<631>Check for break
	JR	NZ,ABORT1	;<631>abort
	ELSE
	@@CKBRKC		;Check for break
	JR	Z,STARTA	;Continue if not
	LD	HL,-1		;  else abort
	RET
;
STARTA	EQU	$
	LD	(EXIT+1),SP	;Save SP location
	ENDIF
;
;	Install or Disable MemDISK
;
	CALL	CALCDRV		;Calculate drive #
	CALL	DOMEM		;Get type of memdisk
	CALL	INSTMEM		;Install MemDISK
;
;	Exit - Clean stack, Set HL, Revector <BREAK>
;
NORMEX	LD	HL,0		;Normal Exit - HL = 0
	JR	EXIT		;Get SP & RETurn
;
ABORT	CALL	GETDUP		;Get duplicate DCT
	IF	@BLD631
ABORT1:
	ENDIF
	LD	HL,-1		;Abort
;
EXIT	LD	SP,$-$		;P/u SP address
	@@CKBRKC		;Clear break
	RET
;
*GET	MEMDISKB:3
*GET	MEMDISKC:3
*GET	MEMDISKA:3
;
	SUBTTL	<>
	END	START
