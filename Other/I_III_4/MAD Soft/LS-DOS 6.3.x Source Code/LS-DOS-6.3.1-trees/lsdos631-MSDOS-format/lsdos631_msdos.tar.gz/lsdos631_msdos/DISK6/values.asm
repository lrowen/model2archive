;VALUES/ASM - Version 6
*LIST OFF
;
; System Flag Offsets
;
CFLAG$	EQU	'C'-'A'
DFLAG$	EQU	'D'-'A'
KFLAG$	EQU	'K'-'A'
SFLAG$	EQU	'S'-'A'
VFLAG$	EQU	'V'-'A'
;
; ASCII character symbols
;
ETX	EQU	3
BS	EQU	8
TAB	EQU	9
LF	EQU	10
PAR_ERR	EQU	44
CR	EQU	13
BREAK	EQU	80H
AP	EQU	39
;
; @PARAM select bit values
;
NUM	EQU	10000000B	;Numeric Input
FLAG	EQU	01000000B	;Flag/Switch Input
STR	EQU	00100000B	;String Input
ABB	EQU	00010000B	;Take 1st Letter Abbrev.
*LIST ON
