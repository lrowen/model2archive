;LBREMOVE/ASM - REMOVE command
	TITLE	<REMOVE - LS-DOS 6.2>
;
*GET	BUILDVER:3
*GET	SVCMAC:3		;SVC Macro equivalents
*GET	VALUES:3		;Misc. equates
;
	ORG	2400H
;
REMOVE
	IF	@BLD631
	LD	(SAVESP+1),SP	;<631>Save Stack
	ENDIF
	@@CKBRKC		;Break key down?
	IF	@BLD631
	JR	NZ,BRKABT	;<631>else abort
	ELSE
	JR	Z,BEGINA	;Ok if not
	LD	HL,-1		;  else abort
	RET
	ENDIF
;
BEGINA
	IF	@BLD631
	ELSE
	LD	(SAVESP+1),SP	;Save Stack
	ENDIF
	CALL	REMOV		;Do the removing
	IF	@BLD631
	ELSE
	JR	EXIT
;
;	Exit Routine - Clear any <BREAK> & return
;
BRKABT
	LD	HL,-1
	JR	SAVESP		;Abort with error
	ENDIF
;
EXIT	LD	HL,0		;Set retcod if exiting
SAVESP	LD	SP,$-$		;P/u stack
	@@CKBRKC		;Clear <BREAK> if entered
	RET			;  and Return
	IF	@BLD631
;
;	Exit Routine - Clear any <BREAK> & return
;
BRKABT				;<631>
	LD	HL,-1		;<631>
	JR	SAVESP		;<631>Abort with error
	ENDIF
;
;	Special Message Exit
;
SPCREQ	LD	HL,SPCREQ$
	@@LOGOT
	IF	@BLD631
ERREXIT	JR	BRKABT		;<631>Get stack & RET
	ELSE
ERREXIT	LD	HL,-1
	JR	SAVESP		;Get stack & RET
	ENDIF
;
;	I/O Error Exit
;
IOERR	LD	L,A		;Error # to HL
	LD	H,0
	OR	0C0H		;Abbrev, return
	LD	C,A		;Error code to reg C
	@@ERROR
	JR	SAVESP		;P/u stack & return
;
;	REMOV - Remove file(s) or device(s)
;
REMOV	PUSH	HL		;Save INBUF$ pointer
REMOV0	XOR	A		;Set Z-flag for loop
REMOV1	POP	HL
	JP	NZ,IOERR
;
;	Skip leading spaces - exit on terminator
;
	@@CKBRKC		;Check for break
	JR	NZ,BRKABT	;  abort if so
;
	DEC	HL
REMOV2	INC	HL		;Skip past spaces
	LD	A,(HL)
	CP	' '
	JR	Z,REMOV2
	RET	C		;Return on terminator
;
;	Hit a non-space char - is this a filespec ?
;
REMOV3	LD	DE,FCB		;Fetch the filespec
	@@FSPEC
	JP	NZ,SPCREQ	;Jump on spec error
	PUSH	HL		;Save INBUF$ pointer
;
;	Transfer Filespec to buff without password
;
	PUSH	DE		;Save FCB ptr
	EX	DE,HL		;Pt HL => FCB
	LD	DE,FILESPC	;DE => Filespec
	CALL	MOVSPC		;Move filespec
	LD	A,CR		;End spec with C/R
	LD	(DE),A
	POP	DE		;Recover FCB
;
;	Are we Removing a Device ?
;
	LD	A,(DE)		;Is it a device?
	CP	'*'
	JR	Z,RMVDVC
;
;	Removing a File - Does it exist ?
;
	@@OPEN			;Open the file
	JR	Z,GOODOPN	;Z - it does exist
	CP	42		;LRL Open Fault ?
	JR	NZ,REMOV1	;No - abort
;
;	Successful Open - Can we Remove the file ?
;
GOODOPN	LD	A,(FCB+1)	;P/u access level
	AND	7
	CP	2		;REMOVE access ?
	LD	A,37		;No - "Illegal access
	JP	NC,IOERR	;  attempted to ..."
;
;	Is there a drivespec in the filespec ?
;
	LD	HL,FILESPC	;HL => Filespec
FLOOP	LD	A,(HL)		;P/u char
	CP	CR+1		;End of Filespec ?
	JR	NC,CHKDSPC
;
;	Drivespec wasn't specified - put it on
;
	LD	(HL),':'	;Append drivespec onto
	INC	HL		;  end of filespec
	LD	A,(FCB+6)	;Xfer drive # to A
	ADD	A,'0'		;Convert to ASCII
	LD	(HL),A
	INC	HL		;Bump
	LD	(HL),CR		;End of filespec
	JR	SHOWFIL		;Dsply name & remove it
;
;	Stop when ":" hit or terminator
;
CHKDSPC	CP	':'		;Already have one ?
	INC	HL
	JR	NZ,FLOOP
;
;	Display "Removing Filespec" & remove it
;
SHOWFIL	CALL	SHOWIT		;"Removing:"
	@@REMOV			;Remove the file
	JR	REMOV1		;Loop for more
;
;	Display Filespec or Devspec
;
SHOWIT	LD	HL,SHOW$	;Show what we are
	PUSH	DE		;Save FCB ptr
	@@DSPLY			;  removing
	POP	DE
	JR	NZ,REMOV1	;NZ - abort
	RET			;  else RETurn Z
;
;	Routine to Remove a device
;
RMVDVC	PUSH	DE		;Xfer FCB ptr to IX
	POP	IX
	LD	E,(IX+1)	;P/u device name
	LD	D,(IX+2)
;
;	Routine to find a device in the device tables
;
	@@GTDCB			;Find this DCB
	JR	NZ,REMOV1	;Abort if not found
;
;	Found device in tables, is it killable?
;
DEV4	LD	(RENDEV+1),DE	;Try to rename it
	PUSH	HL		;Save address pointer
	LD	HL,RENDEV	;New & old names same
	LD	E,L
	LD	D,H
	@@RENAM
	POP	HL		;Rcvr address pointer
	CP	19		;If not "illegal name"
	JP	NZ,REMOV1	;  error, is protected
;
;	Device not system device - is it in use?
;
CKNILL	BIT	3,(HL)		;Test NIL device
	JR	NZ,REMOVIT	;OK if NIL (not in use)
	LD	A,27H		;  else "device in use"
	OR	A
	JP	REMOV1		;  and return error
;
;	Remove the device
;
REMOVIT	CALL	SCND4		;Zero 8-byte DCB area
;
;	Any other device routes to the removed one?
;
SCNDCB	LD	DE,'IK'		;Point to begin of area
	@@GTDCB
SCND1	BIT	4,(HL)		;Routed device?
	JR	Z,SCND2		;Jump if not
	PUSH	HL		;Save DCB pointer
	INC	L		;Bypass TYPE code
	LD	A,(HL)		;P/u route vector
	INC	L		;  lo-order
	LD	H,(HL)		;P/u vector hi-order
	LD	L,A
	LD	A,(HL)		;P/u TYPE code of nest
	POP	HL		;Rcvr DCB pointer
	OR	A		;If TYPE=0, we killed
	JR	NZ,SCND2	;  the routed device
	LD	A,8
	OR	(HL)		;Convert to NIL if so
	LD	(HL),A
	JR	SCNDCB
;
;	Point to next device
;
SCND2	LD	A,L		;Advance to next DCB area
	ADD	A,8		;Loop through all
	LD	L,A		;  devices while checking
	JR	NZ,SCND1	;Loop until table end
;
;	Device table cleared, now zero the DCB/FCB
;
	PUSH	IX		;Xfer vector to HL
	POP	HL
	CALL	SCND4
	CALL	SHOWIT		;Show "Removing:"
	JP	REMOV0		;Next ...
;
SCND4	LD	B,8		;Clear 8 bytes
	XOR	A
SCND5	LD	(HL),A		;Go for it
	INC	HL
	DJNZ	SCND5
	RET
;
;	Transfer a filespec from HL to DE
;
MOVSPC	LD	A,(HL)		;P/u a spec character
	CP	'/'		;Extension ?
	JR	NZ,CKSPACE	;No - check if space
	INC	HL		;Is the next character
	LD	A,(HL)		;  valid ?
	CP	'A'
	JR	C,CKSPACE	;No - don't output it
	DEC	HL		;Back one
	LD	A,(HL)		;P/u slash
CKSPACE	CP	' '
	RET	C		;Stop on space or less
	CP	'.'		;Password ?
	JR	NZ,MOVSPC1
SKIPPW	INC	HL
	LD	A,(HL)
	CP	' '
	RET	C		;Back on terminator
	CP	':'
	JR	NZ,SKIPPW
MOVSPC1	LDI			;Move the char
	JR	MOVSPC
;
SPCREQ$	DB	'File spec required',CR
	IF	@BLD631
RENDEV	DB	'*RS'			;<631>
	ELSE
RENDEV	DB	'*LS'
	ENDIF
SHOW$	DB	'Removing: '
FILESPC	DS	15
FCB	DB	0
	DS	31
;
	END	REMOVE
