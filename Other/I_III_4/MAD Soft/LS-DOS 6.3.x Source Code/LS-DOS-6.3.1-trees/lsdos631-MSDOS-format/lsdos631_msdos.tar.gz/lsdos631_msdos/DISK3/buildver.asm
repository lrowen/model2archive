;
;	Buildver/asm is a bit of a kludge since not all utilities can load
;	equates from LDOS60 and still compile.  LOWCORE and everybody else
;	relies on this setting, and it eventually ends up in LDOS60/EQU
;	for programs that can use that.
;
@BLD631		EQU	-1	;<631>Build 631 distribution (LEVEL 1B)
;	These switches activate patches made since the 1B release.
;	It is important that all earlier patches be enabled when a higher
;	patch is enabled.
;	Patches C thru F were published in TMQ IV.iv, page 32 (NOTE: the
;	patch addresses listed for SPOOL in SPOOL1/FIX are 19H high.)
@BLD631C	EQU	-1	;<631>Apply 1C patches (SETKI)
@BLD631D	EQU	-1	;<631>Apply 1D patches (DIR)
@BLD631E	EQU	-1	;<631>Apply 1E patches (DIR & MEMDISK/DCT)
@BLD631F	EQU	-1	;<631>Apply 1F patches (SPOOL)
;	Patches G and H were published in TMQ V.i, pages 10 and 18/19.
@BLD631G	EQU	-1	;<631>Apply 1G patches (//KEYIN,DIR,DO *)
@BLD631H	EQU	-1	;<631>Apply 1H patches (MEMORY)
;
;End of BUILDVER/ASM
