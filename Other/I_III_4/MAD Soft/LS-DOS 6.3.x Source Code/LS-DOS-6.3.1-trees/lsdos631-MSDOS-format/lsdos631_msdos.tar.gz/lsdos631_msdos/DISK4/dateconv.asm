;DATECONV/ASM - 6.3 Date Conversion Program
	TITLE	<DATECONV - LS-DOS 6.3>
; 01/14/86 - Add set 63h version # at gat+CB when done
;
LF	EQU	10
CR	EQU	13
BLNKMPW	EQU	4296H
;
*GET	SVCMAC:3		;SVC Macro equivalents
*GET	COPYCOM:3		;Copyright message
;
	ORG	2600H
BEGIN
	IF	@BLD631
	LD	(STACK),SP	;<631>Save entry stack
	@@CKBRKC		;<631>Check for break
	JP	NZ,ABORT	;<631>abort
	ELSE
	@@CKBRKC		;Check for break
	JR	Z,BEGINA	;Continue if not
	LD	HL,-1		;  else abort
	RET
;
BEGINA
	LD	(STACK),SP	;Save entry stack
	ENDIF
	PUSH	HL		;Save ptr to cmdline
	LD	HL,HELLO$	;Display the signon
	CALL	$DSPLY
	POP	HL
	CALL	PGRM		;Normal exit is via RET
;
;	Set exit condition..
;
$EXIT	LD	HL,0		;Init for no error
QUIT$	LD	SP,$-$		;P/u original stack
STACK	EQU	$-2
	@@CKBRKC		;Clear break before exit
	RET
;
PGRM	LD	A,(HL)		;Ck for drive entered
	CP	' '		;Bypass leading spaces
	INC	HL
	JR	Z,PGRM
	CP	':'		;Colon indicator?
	JP	NZ,ILLEG	;Quit if not
	LD	A,(HL)		;P/u drive
	SUB	'0'		;Cvrt to binary
	JP	C,ILLEG		;Bad drive #
	CP	8		;Bigger than 7?
	JP	NC,ILLEG	;Quit if so
;
	LD	(DRIVE1),A
	LD	(DRIVE2),A	;Save for read and write
DOPRM:	INC	HL		;See if any params
	LD	A,(HL)
	CP	CR+1		;End?
	JR	C,NOPRM		;Go if so
	CP	' '		;Space?
	JR	Z,DOPRM		;Bypass
	CP	'('
	JR	NZ,DOPRM
	LD	DE,PRMTBL
	@@PARAM
	JP	NZ,IOERR
NOPRM:	LD	A,(DRIVE1)	;Get back drive
	LD	C,A
	@@CKDRV			;Be sure disk is in
	JP	NZ,ILLEG
	JP	C,WPDRV
	@@GTDCT
;
	LD	A,(IY+9)	;Get dir cyl
	LD	(DIR1),A
	LD	D,A		;Set to read GAT
	LD	E,0
	CALL	RDSEC		;Read the GAT
	LD	DE,$-$		;See if force all
CSPARM	EQU	$-2
	LD	A,D
	OR	E
	JR	NZ,DOIT		;Go if it is
	LD	A,(BUF1+0CDH)	;Get the type byte
	BIT	3,A		;Have some new already?
	JP	Z,DOOLD		;Go if not
	LD	(HAVNEW),A	;Else set new on
	JR	DOIT		;  and start
DOOLD	BIT	7,A		;Is it a system disk?
	JR	NZ,DOIT		;Start if not
	LD	DE,2		;If sys disk,
	CALL	RDSEC		; must check version
	LD	A,(HL)
	CP	63H		;Cannot be earlier
	JR	Z,DOIT		;Go if 6.3 or later
	JP	NOT2SYS		;  else abort
;
;	Get directory records
;
DOIT	LD	D,$-$
DIR1	EQU	$-1
	LD	E,3		;Read directory
	CALL	RDSEC
	LD	A,(BUF1+20)	;Get the ERN of DIR
	SUB	1
	CP	33		;Max allowed is 34 total
	JR	C,SET1		;Go if ok
	LD	A,33		;  else set max sectors number
SET1	LD	(MAXSEC),A	;Save for countdown
;
;	Main driving loop
;
	LD	E,2		;Starting directory record
DIRLOOP	CALL	RDSEC
DIRLP1	PUSH	HL
	BIT	7,(HL)		;FXDE?
	JP	NZ,DONXT	;Go if so
	BIT	4,(HL)		;Alive?
	JP	Z,DONXT		;Go if not
	INC	L
	INC	L
	LD	A,(HL)		;Get the date
	OR	A		;Was one set?
	JR	Z,DONXT		;Go if not
	AND	7		;Save possible year
	LD	C,A		; in C
	LD	A,L		;Pt to date/time or pswd
	ADD	A,16		;  as the case may be
	LD	L,A
	LD	A,$-$		;Are there new files?
HAVNEW	EQU	$-1
	OR	A
	JR	Z,NONEW		;Go if not
	PUSH	DE
	PUSH	HL		;Save direc locn
	LD	DE,BLNKMPW	;See if this file has
	LD	A,(HL)
	INC	HL
	LD	H,(HL)
	LD	L,A		; a blank password
	OR	A
	SBC	HL,DE
	POP	HL
	POP	DE
	JR	NZ,DONXT	;Go if not
;
;	Do this file
;
NONEW	LD	(HL),0		;Xfer hours,mins
	INC	HL
	LD	(HL),C		;Xfer mins,year
	LD	HL,(CNT)
	INC	HL
	LD	(CNT),HL	;Inc count of matches
;
DONXT	@@CKBRKC
	JP	NZ,WASBRK	;Quit on break
	POP	HL
	LD	A,L
	ADD	A,20H
	LD	L,A
	JP	NZ,DIRLP1	;Go if more this sect
	CALL	WRSYS		;Write the dir sector
	LD	A,$-$
MAXSEC	EQU	$-1
	INC	E		;Next sector
	CP	E		;Are we done?
	JP	NC,DIRLOOP	;Cont if not
;
;	Update GAT type byte
;
	LD	E,0
	CALL	RDSEC
	LD	A,(BUF1+0CDH)	;Get the type byte
	OR	8		;Set the bit
	LD	(BUF1+0CDH),A	; put it back
	IF	@BLD631
	LD	A,63H		;<631>Update version # in GAT
	LD	(BUF1+0CBH),A	;<631>
	CALL	WRSYS		;<631>
	ELSE
	CALL	PATCH1  
	ENDIF
;
;	Show how many found
;
	LD	HL,(CNT)	;Get count of changes
	LD	DE,CNTMSG$
	PUSH	DE
	@@HEXDEC
	POP	HL
	@@LOGOT
	RET			;All done
;
;	Support subroutines
;
$DSPLY	@@DSPLY			;Display a line
	RET	Z
	JR	IOERR
;
;	Write the current sector
;
WRSYS	LD	HL,BUF1
	LD	C,$-$
DRIVE1	EQU	$-1
	@@WRSSC
	JR	NZ,IOERR
	@@VRSEC
	CP	6
	JR	NZ,IOERR
	RET
;
;
;	Sector read routine
;
RDSEC	LD	HL,BUF1		;Read sector
	LD	C,$-$
DRIVE2	EQU	$-1
	@@RDSEC	
	RET	Z
	CP	6
	RET	Z		;Fall thru to error?
;
;	Error exits
;
IOERR	CP	63		;Extended error?
	JR	Z,EXTERR	;Log it and quit
	LD	H,0		;Error to HL
	LD	L,A
	PUSH	HL		;Save error code
	OR	0C0H		;Set short, return
	LD	C,A		;Error to C for
	@@ERROR			;  display
	POP	HL		;Recover error code
	JR	QUIT$$
;
;	Internal error handler
;
NOT2SYS	LD	HL,NOT2SYS$	;"Can't do 6.2 sys disk
	DB	0DDH
WPDRV	LD	HL,WPDRV$	;"Write protected drive
	DB	0DDH
WASBRK	LD	HL,ABTJOB$
EXTERR	@@LOGOT			;Display the error
	IF	@BLD631
ABORT:
	ENDIF
	LD	HL,-1		;Set abort code
QUIT$$	JP	QUIT$
;
ILLEG	LD	A,32		;'illegal drv #'
	JP	IOERR
;
;
;	Messages
;
HELLO$	DB	'DATECONV'
*GET	CLIENT:3
;
CNTMSG$	DB	'      file(s) updated, conversion complete',CR
ABTJOB$	DB	'Date conversion aborted',CR
NOT2SYS$	DB	'Can''t convert dates on a non-6.3 '
	DB	'SYSTEM disk',CR
WPDRV$	DB	'Write protected drive',CR
;
PRMTBL	DB	80H
	DB	42H
	DB	'CS'
	DB	0
	DW	CSPARM
	DW	0
MINS	DB	0
HOURS	DB	0
CNT	DW	0
;
	ORG	$<-8+1<+8
BUF1	DS	256
	IF	@BLD631
	ELSE
PATCH1	LD	A,63H		;Update version # in GAT
	LD 	(BUF1+0CBH),A
	JP	WRSYS
	ENDIF
;
	END	BEGIN
