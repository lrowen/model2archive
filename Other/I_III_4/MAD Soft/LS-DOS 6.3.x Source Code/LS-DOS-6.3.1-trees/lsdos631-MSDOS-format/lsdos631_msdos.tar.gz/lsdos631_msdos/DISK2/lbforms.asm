;LBFORMS/ASM - Set Line Printer Values
	TITLE	<FORMS - LS-DOS 6.2>
;
;
PAR_ERR	EQU	44		;Parameter Error Code
FLAGBT	EQU	7		;Flag byte offset
ADDLF	EQU	7		;Add Line Feed = Bit 0
FFHARD	EQU	7		;Form Feed Hard = Bit 1
TABV	EQU	7		;Tab Expansion = Bit 2
CHARS	EQU	8		;Characters per line
INDENT	EQU	6		;Indent after wrap-around
LINES	EQU	2		;Maximum Lines to Print
MARGIN	EQU	9		;Left hand margin value
PAGE	EQU	0		;Maximum Lines per page
XLATEF	EQU	4		;Xlate From
XLATET	EQU	5		;Xlate To
;
PDEF	EQU	66		;Page Default = 66
LDEF	EQU	66		;Line Default = 66
;
CURON	EQU	0EH		;Cursor on
CUROFF	EQU	0FH		;Cursor off
SKIP	EQU	0DDH		;Skip 3 byte instruction
;
*GET	SVCMAC:3		;SVC Macro equivalents
*GET	VALUES:3		;Misc. equates
;
	ORG	2400H
;
START
	LD	(SAVESP+1),SP	;Save SP loc
	CALL	FORMS		;Execute Form Code
EXIT	LD	HL,0		;Set no error
	JR	SAVESP		;Exit
;
;	I/O Error Handling
;
PRMERR	LD	A,PAR_ERR	;Parameter Error
IOERR	LD	L,A		;Xfer error # to HL
	LD	H,0
	OR	0C0H		;Abbrev, return
	LD	C,A		;Xfer to C
	@@ERROR			;Display error
	JR	SAVESP		;Go to exit routine
;
;	Internal Error Message Handling
;
NOPF	LD	HL,NOPF$	;No filter present
	@@LOGOT			;Log Message
ABORT	LD	HL,-1		;Set abort code
SAVESP	LD	SP,$-$		;P/u original SP
	@@CKBRKC		;Clear any <BREAK>
	RET			;And RETurn to DOS
;
;	FORMS - Process the Forms Filter Parameters
;
FORMS
	CALL	DOINIT		;Do initialization
;
;	Ignore Leading Spaces
;
	DEC	HL
IGSPCS	INC	HL		;Bump cmdline ptr
	LD	A,(HL)		;Skip leading spaces
	CP	' '
	JR	Z,IGSPCS
;
;	Any Parameters Entered ?
;
	CP	CR+1		;End of line ?
	JR	NC,GETPRM	;Go if not
;
;	Display current parameter settings
;
DISPFRM	CALL	DSFORMS		;Create default string
	CALL	DSPLY		;Display defaults
	RET			;  and RETurn
;
;	Display "Paramter Error" if Illegal input
;
GETPRM	LD	DE,PRMTBL$	;Any Paramters ?
	@@PARAM	
	JP	NZ,PRMERR	;NZ - "Parameter Error"
;
;	Create Xlate From Data Area
;
	LD	A,(XTRESP)	;P/u xlate TO response
	LD	(XFRESP),A	;Xfer to FROM response
	LD	HL,XTPARM+1	;HL => XLATE To
	LD	A,(HL)		;P/u value
	LD	(HL),0		;Set Xlate To msb = 0
	LD	(XFPARM),A	;Xfer to From parm
;
;	Over-ride all other parms if <D>efault
;
	LD	A,(DRESP)	;<D>efault Parm entered ?
	OR	A
	JR	Z,CHECKQ	;No - check for <Q>uery
;
;	Overwrite $FF data area with default values
;
	LD	DE,(DATAREA+2)	;DE => Data area start
	LD	BC,10		;BC = 10 bytes in table
	LD	HL,DEFTAB	;HL => Default Table
	PUSH	HL		;Save regs
	PUSH	BC
	LDIR			;Xfer to $FF data area
	POP	BC
	POP	HL
	LD	DE,DUPDA
	LDIR			;Xfer to duplicate DA
	JR	DISPFRM		;Display forms & exit
;
;	Prompt for any parms not entered & stuff
;
CHECKQ	EQU	$
	CALL	INITVAL		;Init parm values = def's
	CALL	DSFORMS		;Create string
	LD	A,(QRESP)	;<Q>uery parm used?
	OR	A
	CALL	Z,CKCOMM	;Check cmdline values if not
	CALL	NZ,PROMPT	;Prompt if "Q"
STUFFIN	CALL	STFPRMS		;Stuff parms in $FF data
	JP	EXIT		;Good exit
;
;	Display Current FORMS value settings
;
DSFORMS	BIT	0,(IX+ADDLF)	;Add line feed ?
	LD	DE,SADDLF	;DE => addlf dsply msg
	CALL	NZ,XFERON	;Put "ON" in message
;
;	Display "OFF" if zero, or value if <> zero
;
	LD	A,(IX+CHARS)	;CHARS value if it wasn't
	OR	A		;OFF ?
	LD	DE,SCHARS	;DE => Chars msg
	CALL	NZ,HEXDEC	;Convert value to dec ASCII
	JR	NZ,DOFFHRD	;Go if Char parm used
;
CHAROFF	LD	HL,OFFSTR	;  else xfer "OFF" into
	CALL	XFER		;  Chars message
;
;	FFHARD specified ?
;
DOFFHRD	BIT	1,(IX+FFHARD)	;FFHARD parm used?
	LD	DE,SFFHARD	;DE => Ffhard msg
	CALL	NZ,XFERON	;Xfer "ON" if set
;
;	Xfer INDENT value into string
;
	LD	A,(IX+INDENT)	;Default value
	LD	DE,SINDENT	;DE=> Indent msg
	CALL	HEXDEC		;Convert to decimal ASCII
;
;	Xfer LINES value into string
;
	LD	A,(IX+LINES)	;P/u LINES value
	LD	DE,SLINES	;Pt to Lines msg
	CALL	HEXDEC		;Convert to decimal ASCII
;
;	Xfer MARGIN value into string
;
	LD	A,(IX+MARGIN)	;P/u MARGIN value
	LD	DE,SMARGIN	;DE => Margin msg
	CALL	HEXDEC		;Convert to decimal ASCII
;
;	Xfer PAGE value into string
;
	LD	A,(IX+PAGE)	;P/u page value
	LD	DE,SPAGE	;DE => Page msg
	CALL	HEXDEC		;Convert to decimal ASCII
;
;	Xfer "ON" into string if Tab set
;
	BIT	2,(IX+TABV)	;Check Tab bit
	LD	DE,STAB		;DE => Tab msg
	CALL	NZ,XFERON	;Xfer "ON" if set
;
;	Is Xlate FROM = Xlate TO ?
;
	LD	A,(IX+XLATEF)	;P/u FROM byte
	LD	B,(IX+XLATET)	;P/u TO byte
	CP	B		;Same ?
	JR	Z,NOSHOW	;Yes - no show
;
;	Two distinct values - convert to Hex
;
	LD	HL,DOXLATE	;Change CR to LF
	LD	(HL),LF		;  so msg will dsply
;
	LD	HL,SXLFROM	;"From" message
	CALL	HEX8		;Convert A to Hex @ HL
	LD	A,B		;P/u TO
	LD	HL,SXLTO	;"To" message
	CALL	HEX8		;Convert A to Hex @ HL
;
;	Point HL to string & RETurn
;
NOSHOW	LD	HL,VALUES	;HL => Default val string
	RET			;RETurn
;
;
;	CKCOMM - Check command line parameter values
;
;
CKCOMM	LD	E,10		;10 values to check
	LD	IY,STRTAB	;IY => Response table
;
CKCOMML	LD	L,(IY+1)	;P/u address of response
	LD	H,(IY+2)
;
;	Set BC = Parameter Response
;
	LD	A,(HL)		;Was anything entered ?
	OR	A
	INC	HL		;Parm addr follows resp
	LD	C,(HL)		;Set HL = (HL)
	INC	HL
	LD	H,(HL)
	LD	L,C
	LD	C,(HL)		;P/u response value
	INC	HL		;  into BC
	LD	B,(HL)
;
;	Call routine to Range check parm entry
;
	LD	L,(IY+5)	;P/u address of routine
	LD	H,(IY+6)	;  to check value validity.
	LD	(CALLINS+1),HL	;Stuff addr to CALL instr
CALLINS	CALL	NZ,$-$		;BC = response, A = type
	JP	NZ,PRMERR	;NZ - "Parameter Error"
;
;	Position to next table entry
;
	LD	BC,9		;Pos to next STRTAB entry
	ADD	IY,BC
	DEC	E		;Done ?
	JR	NZ,CKCOMML
	RET			;Yes - RETurn
;
;
;	PROMPT - for any vals not entered in parm line
;
PROMPT	LD	B,10		;Eight normal + 2 Xlates
	LD	IY,STRTAB	;Prompt, response table
;
;	P/u type byte from table & set length = 1
;
PROMPTL	LD	A,(IY)		;P/u type byte
	INC	A		;Merge length = 1
	LD	(FAKETAB+1),A	;Store new type byte
;
;	P/u address of response byte
;
REINPUT	LD	E,(IY+1)	;P/u address
	LD	D,(IY+2)	;  in DE
;
;	Pick up Prompt string address & display it
;
DOPRMPT	LD	L,(IY+3)	;P/u address in HL
	LD	H,(IY+4)
	CALL	DISPROM		;P/u default & display
;
;	Input response & stuff into Parm table
;
	CALL	INPUT		;Input value
	PUSH	BC		;Save count
	CALL	NZ,STUFVAL	;Stuff in valid input
	POP	BC		;Restore count
	JR	NZ,REINPUT	;Re-input if bad value
;
;	Position to next table entry
;
NEXTPR	LD	DE,9		;9 bytes per entry
	ADD	IY,DE
	DJNZ	PROMPTL		;B prompts
	RET			;Done
;
;
;	DISPROM - Display Prompt
;
DISPROM	PUSH	DE		;Save regs
	PUSH	BC
	LD	C,CUROFF	;Turn off cursor
	CALL	DSP
	LD	B,32		;Space padding base
;
PRLP	LD	C,(HL)		;P/u character
	INC	HL		;Pos to next
	DEC	B		;Dec count
	CALL	DSP		;Output byte
	LD	A,C		;P/u char
	CP	'{'		;Bracket ?
	JR	NZ,PRLP		;No - go til bracket
	CALL	STUFDEF		;Display default
	LD	A,B		;P/u base #
	ADD	A,C		;  & calculate # of
	LD	B,A		;Spaces to print
	LD	C,' '
;
SPLP	CALL	DSP		;Output spaces
	DJNZ	SPLP
;
	LD	HL,ENDPROM	;End of prompt
	CALL	DSPLY
	POP	BC		;Recover regs
	POP	DE
	RET			;  and RETurn
;
;
;	STUFDEF - Stuff default value in prompt
;
STUFDEF	LD	L,(IY+7)	;P/u default string
	LD	H,(IY+8)	;  address
	LD	C,5		;5 chars max
PNLP	LD	A,(HL)
	INC	HL		;Bump source
	CP	LF		;Done ?
	JR	Z,DUNLP
	CP	' '		;Leading space ?
	JR	Z,PNLP		;Yes - ignore it
	CALL	DISPA		;Output A
;
PNLP2	DEC	C		;Dec count
	JR	NZ,PNLP
;
DUNLP	LD	A,'}'		;Output end bracket
DISPA	PUSH	BC		;Save count in C
	LD	C,A		;Xfer char to C
	CALL	DSP		;Output byte
	POP	BC		;Recover C
	RET			;  and RETurn
;
;
;	STUFVAL - Stuff values into Parm Table
;
STUFVAL	PUSH	DE		;DE => Response Byte
	LD	HL,FAKEPRM	;HL => Fake Parm Entry
	LD	DE,FAKETAB	;DE => Fake Parm Table
	@@PARAM			;Parse entry
	POP	HL		;HL => Response
	RET	NZ		;NZ - Re-input
;
;	Stuff response into Parameter Table
;
	PUSH	HL		;Save response dest
	LD	A,(FAKERES)	;P/u response
VALUE	LD	BC,$-$		;P/u value
	INC	HL		;HL => Parm Address
	LD	E,(HL)		;P/u parm address
	INC	HL
	LD	D,(HL)
	EX	DE,HL		;HL => Parm lsb
	LD	(HL),C		;Stuff response in table
;
;	CALL range checking routine
;
	LD	HL,RETADR	;Put RET addr on stack
	PUSH	HL
	LD	L,(IY+5)	;P/u addr of range
	LD	H,(IY+6)	;Checking in HL
	JP	(HL)		;Routine sets Z for stat
RETADR	POP	HL		;HL => Response byte
	RET	NZ		;Don't change if NZ
	LD	(HL),80H	;  else stuff non-zero
	RET			;  value for response
;
;
;	STFPRMS - Stuff Numeric & Flag Parms into $FF
;
;
;	Pt HL => Response byte addr & offset Table
;
STFPRMS	LD	HL,RESPTAB	;HL => Response Table
DATAREA	LD	IX,$-$		;P/u Data Area pointer
	LD	B,7		;7 numeric values
;
;	P/u response byte & offset byte to $FF data
;
STUFLP	LD	E,(HL)		;P/u response address
	INC	HL
	LD	D,(HL)
	INC	HL		;HL => $FF data offset
	LD	C,(HL)		;P/u offset in data area
	INC	HL
;
	LD	A,(DE)		;P/u response
	OR	A		;Parm entered ?
;
;	Parm entered - calculate Parm's Location
;
	INC	DE		;DE => Parameter Dest
	EX	DE,HL		;Xfer to HL
	LD	A,(HL)		;Set HL = (HL)
	INC	HL
	LD	H,(HL)
	LD	L,A
;
;	Stuff parm response into $FF data region
;
	LD	A,C		;Xfer offset to A
	LD	C,(HL)		;P/u lsb of Parm response
	EX	DE,HL		;Recover HL (Table ptr)
NOPOUT	JR	Z,NOPARM	;No - don't stuff
	LD	(IXINST+2),A	;Modify offset in IX inst
IXINST	LD	(IX+$-$),C	;Xfer parm resp to $FF
;
NOPARM	DJNZ	STUFLP		;Next entry
;
;	Set Flag bits in $FF data area if parms set
;
GETFLAG	LD	B,3		;3 flag values
FLOOP	LD	E,(HL)		;P/u response address
	INC	HL
	LD	D,(HL)
	INC	HL
	LD	A,(DE)		;Entered ?
	OR	A
	JR	Z,NEXTFLG	;No - get next one
;
;	Response - If true (SET), False (RES)
;
	INC	DE		;Pos to parm address
	EX	DE,HL		;P/u Parm
	LD	A,(HL)		;Set HL = (HL)
	INC	HL
	LD	H,(HL)
	LD	L,A
	EX	DE,HL		;Put into DE
	LD	C,10000110B	;Default = Reset bit inst
	LD	A,(DE)		;P/u lsb of parm
	OR	A		;Set ?
	JR	Z,SKIPSET	;No - skip SET inst
	SET	6,C		;Change to Set bit inst
;
;	Create Post opcode for IX instruction
;
SKIPSET	LD	A,B		;P/u bit # (0-2)
	DEC	A
	RLCA			;Move to bits 3-5
	RLCA
	RLCA
	OR	C		;Post op code
	LD	(IXINST2+3),A	;Change RES b,(IX+nn) ins
IXINST2	RES	$-$,(IX+FLAGBT)	;Set/Reset bit B in $FF
NEXTFLG	DJNZ	FLOOP		;Get next flag
	RET			;Done - RETurn
;
;
;	INITVAL - Initial Parm values
;
;
INITVAL	LD	B,5		;5 values to stuff
	LD	HL,RESPTAB	;HL => Response & offsets
;
SDLP	LD	E,(HL)		;P/u response byte addr
	INC	HL
	LD	D,(HL)
	INC	HL
	LD	A,(DE)		;P/u response byte
;
;	Get parm table address - DE = (DE)
;
	EX	DE,HL
	INC	HL		;Parm address after resp
	LD	C,(HL)		;P/u lsb
	INC	HL
	LD	H,(HL)		;P/u msb
	LD	L,C		;HL = (HL)
	EX	DE,HL		;Get back to DE
;
;	P/u default value from $FF data area
;
	PUSH	DE		;Save HL & DE
	PUSH	HL
	LD	E,(HL)		;P/u offset
	LD	D,0		;DE = offset to default
	LD	HL,(DATAREA+2)	;HL => Data Area
	ADD	HL,DE
	LD	C,(HL)		;P/u default value
	POP	HL		;Restore regs
	POP	DE
;
;	If parm wasn't entered - stuff default value
;
	INC	HL		;Posn to next entry
	OR	A		;Parm entered ?
	JR	Z,STFDEF	;No - stuff default
	LD	A,(QRESP)	;<Q>uery parm used?
	OR	A
	JR	Z,PRMENT	;No - don't stuff
STFDEF	LD	A,C		;Yes - stuff default
	LD	(DE),A
PRMENT	DJNZ	SDLP
	RET			;Done
;
;
;	Range Checking Code of Values
;
;
;	Is the Page length valid ?
;
RPAGE	CALL	MORE0?		;Number between 1 - 255 ?
	RET	NZ		;No - NZ
	LD	A,(LPARM)	;P/u LINES value
	DEC	A
	CP	C		;LINES > PAGE ?
	PUSH	AF		;Save status
	LD	A,(QRESP)	;<Q>uery parm used?
	OR	A
	JR	NZ,PQUERY	;Go if so
	POP	AF		;No
	JR	VALID2?		;Return NZ if L>P
PQUERY	POP	AF		;L > P ?
	JR	C,SETZ		;No - Set Z flag
	LD	A,C		;Yes - Set LINES = PAGE
	LD	(DUPDA+LINES),A
	LD	(LRESP),A	;Pretend that LINES was
	LD	(LPARM),A	;  responded to
	CALL	DSFORMS		;Reset defaults
SETZ	CP	A		;Set Z flag
	RET
;
;	Is the lines printed per page valid ?
;
RLINES	CALL	MORE0?		;Number between 1 - 255 ?
	RET	NZ		;No - NZ
	DEC	A
	LD	HL,PPARM	;HL => Page length
	JR	VALID1?		;Set status accordingly
;
;	Is the Characters printed per line valid ?
;
RCHARS	BIT	6,A		;Flag response ?
	JR	NZ,SETZ		;Yes - Set Z
	CALL	MORE0?		;No - More than zero ?
	RET	NZ		;No - NZ
	LD	A,(QRESP)	;<Q>uery parm used?
	OR	A
	RET	Z		;Return if not
;
;	<Q>uery - Make sure CHARS > INDENT+MARGIN
;
	LD	HL,MPARM	;HL => Margin value
	LD	A,(IPARM)	;A = Indent value
	ADD	A,(HL)		;A = Indent + Margin
	CP	C		;Less than CHARS ?
	JR	C,SETZ		;Yes - Set Z
	XOR	A		;Reset INDENT & MARGIN=0
	LD	(DUPDA+INDENT),A
	LD	(DUPDA+MARGIN),A
	LD	(IPARM),A
	LD	(MPARM),A
	INC	A		;Pretend that INDENT &
	LD	(MRESP),A	;  MARGIN were responded
CHNGIND	LD	(IRESP),A	;  to
	CALL	DSFORMS		;Change defaults
	XOR	A		;Set Z & RETurn
	RET
;
;	Is Margin less than Characters/Line ?
;
RMARGIN	CALL	NUMERIC		;Number between 0 - 255 ?
	RET	NZ		;No - NZ
	CALL	VALID?		;Yes - less than CHARS ?
	RET	NZ		;No - RETurn NZ
	LD	A,(IPARM)	;P/u INDENT
	ADD	A,C		;Add to MARGIN
	CALL	VALID?		;M + I < CHARS ?
	RET	Z		;Yes - RETurn Z
	XOR	A		;No - Set INDENT default
	LD	(IPARM),A	;Equal to Zero
	LD	(DUPDA+INDENT),A
	INC	A		;Pretend I was responded
	JR	CHNGIND		;  to
;
;	Is Margin + Indent less than chars/line ?
;
RINDENT	CALL	NUMERIC		;Number between 0 - 255 ?
	RET	NZ		;No - NZ
	LD	A,(MPARM)	;P/u MARGIN val
	ADD	A,C		;A = MARGIN + INDENT
VALID?	LD	HL,CPARM	;HL => Characters/Line
VALID1?	CP	(HL)		;Response > (HL) ?
VALID2?	JR	NC,SETNZ	;Yes - Reset Z flag
	CP	A		;No - Set Z flag
	RET
SETNZ	XOR	A		;Reset Z flag
	INC	A
	RET
;
;	Is the response a number between 1-255 ?
;
MORE0?	CALL	NUMERIC		;Is the response a number
	RET	NZ		;Between 0 - 255 ?
	OR	A		;Is the response zero ?
	JR	Z,SETNZ		;Yes - reset Z flag
	CP	A		;No - set Z flag
	RET
;
;	Is the response a 1 byte number ?
;
NUMERIC	AND	80H		;Bit 7 is set if the
	XOR	80H		;Response is numeric.
	RET	NZ		;NZ <= if Bit is reset
	INC	B		;Is the response only
	DEC	B		;1 byte (msb = 0) ?
	LD	A,C		;Set A = response
	RET			;Yes (Z), no (NZ)
;
;	Is the response a flag (ON/YES, OFF/NO) ?
;
FLAG?	AND	40H		;Bit 6 is set if the
	XOR	40H		;Response is a flag.
	RET			;Yes (Z), no (NZ)
;
;
;	XFER - Xfer string @ HL to DE
;	XFERON - Xfer "ON" string to DE
;
;
XFERON	LD	HL,ONSTR	;HL => "ON"
XFER	LD	BC,3		;3 chars to xfer
	LDIR
	RET
;
;
;	DSP - Display a byte
;
;
DSP	PUSH	DE		;Save DE
	@@DSP			;Output byte
	JR	EXDSP
;
;
;	DSPLY - Display a string
;
;
DSPLY	PUSH	DE		;Save DE
	@@DSPLY			;Display it
EXDSP	POP	DE
	RET	Z		;Return if good
	JP	IOERR		;NZ - I/O Error
;
;
;	DOINIT - Sign on message & Get Data area
;
;
DOINIT	PUSH	HL		;Save command ptr
	@@FLAGS			;Get system flags
;
;	Point IX to Filter Data area
;
	LD	DE,$FF		;DE => "$FF"
	@@GTMOD			;Find start
	JP	NZ,NOPF		;Abort if Forms/Flt missing
;
	EX	DE,HL		;HL => Data Area
	LD	BC,4		;Add 4 to ptr
	ADD	HL,BC
	LD	(DATAREA+2),HL	;Save $FF data pointer
	LD	DE,DUPDA	;DE => Duplicate D area
	PUSH	DE		;Save ptr
	LD	C,10		;BC = 10 bytes to xfer
	LDIR
	POP	IX		;IX pts to data area
	POP	HL		;Recover cmdline ptr
	RET			;  and RETurn
;
;
;
;	HEXDEC - Convert Hex Number to Decimal ASCII
;	A => 8-bit Hex Number to Convert
;	DE => Destination of ASCII characters
;
;
HEXDEC	PUSH	BC		;Save regs
	PUSH	HL
	PUSH	AF
;
;	Transfer ASCII chars into temporary buffer
;
	PUSH	DE		;Save real destination
	LD	DE,TEMBUF	;DE => Temporary buffer
	LD	H,0		;Xfer # to HL
	LD	L,A
	@@HEXDEC		;Convert to ASCII
	DEC	DE		;Pos to 3-byte field
	DEC	DE
	DEC	DE
	POP	HL		;Recover user buffer
	EX	DE,HL		;HL to #, DE to user buff
	LD	BC,3
	LDIR			;Move the ASCII number
;
	POP	AF		;Recover #
	POP	HL		;  and other regs
	POP	BC
	RET
;
;
;	HEX8 - Convert HEX Number in A to HEX @ HL
;
;
HEX8	PUSH	BC		;Save regs
	LD	C,A		;Xfer char to C
	@@HEX8			;Do it
	POP	BC
	RET			;  and RETurn
;
;
;
;	INPUT - Input a string into INBUFF$
;
;
INPUT	PUSH	HL		;Save regs
	PUSH	DE
	PUSH	BC
;
	LD	BC,3<8		;3 chars max
	LD	HL,INBUFF$	;Key input buffer
	@@KEYIN			;Input line
	JP	C,ABORT		;Abort if <BREAK>
;
	INC	B		;Set Z flag if
	DEC	B		;  no input
;
	POP	BC		;Restore regs
	POP	DE
	POP	HL
	RET			;  & RETurn with condition
;
;	Default Value Table
;
DEFTAB	DB	PDEF,0,LDEF,0,0,0,0,00000100B,0,0
;
;	Parameter table
;
PRMTBL$	DB	80H		;6.2 @PARAM
;
;	ADDLF (A) - Flag Input Only
;
	DB	FLAG!ABB!5
	DB	'ADDLF'
ARESP	DB	0
	DW	APARM
;
;	CHARS (C) - Accept Numeric or Flag input
;
	DB	FLAG!ABB!NUM!5
	DB	'CHARS'
CRESP	DB	0
	DW	CPARM
;
;	FFHARD (F) - Accept Flag input only
;
	DB	FLAG!ABB!6
	DB	'FFHARD'
FRESP	DB	0
	DW	FPARM
;
;	INDENT (I) - Accept Numeric Input only
;
	DB	NUM!ABB!6
	DB	'INDENT'
IRESP	DB	0
	DW	IPARM
;
;	LINES (L) - Accept Numeric Input only
;
	DB	NUM!ABB!5
	DB	'LINES'
LRESP	DB	0
	DW	LPARM
;
;	MARGIN (M) - Accept Numeric Input only
;
	DB	NUM!ABB!6
	DB	'MARGIN'
MRESP	DB	0
	DW	MPARM
;
;	PAGE (P) - Accept Numeric Input only
;
	DB	NUM!ABB!4
	DB	'PAGE'
PRESP	DB	0
	DW	PPARM
;
;	QUERY (Q) - Accept Flag Input Only
;
	DB	FLAG!ABB!5
	DB	'QUERY'
QRESP	DB	0
	DW	QPARM
;
;	TAB (T) - Accept Flag input only
;
	DB	FLAG!ABB!3
	DB	'TAB'
TRESP	DB	0
	DW	TPARM
;
;	XLATE (X) - Accept Numeric input only
;
	DB	NUM!ABB!5
	DB	'XLATE'
XTRESP	DB	0
	DW	XTPARM
;
;	DEFAULT (D) - Accept Flag input only
;
	DB	FLAG!ABB!7
	DB	'DEFAULT'
DRESP	DB	0
	DW	DPARM
;
	DB	0
;
QPARM	DW	0
CPARM	DW	0
IPARM	DW	0
LPARM	DW	0
MPARM	DW	0
PPARM	DW	0
XTPARM	DW	0
;
APARM	DW	0
FPARM	DW	0
TPARM	DW	0
DPARM	DW	0
;
XFRESP	DB	0
	DW	XFPARM
XFPARM	DW	0
;
;
;	Response Table - Response Addr, $FF Offset
;
;
;	8-bit Numeric Responses
;
RESPTAB	DW	CRESP
	DB	CHARS
;
	DW	IRESP
	DB	INDENT
;
	DW	LRESP
	DB	LINES
;
	DW	MRESP
	DB	MARGIN
;
	DW	PRESP
	DB	PAGE
;
	DW	XTRESP
	DB	XLATET
;
	DW	XFRESP
	DB	XLATEF
;
;	Flag Response Table
;
	DW	TRESP
	DW	FRESP
	DW	ARESP
;
;
FAKEPRM	DB	'(F='
INBUFF$	DS	12
;
;
;	STRTAB - 10 entries each with 9 bytes:
;
;	1 byte : Type of expected response - flag or numeric
;	2 bytes: Address of response byte
;	2 bytes: Address of prompt string
;	2 bytes: Address of routine to range check response
;	2 bytes: Address of default value string
;
;
;
STRTAB	EQU	$
	DB	NUM		;PAGE
	DW	PRESP,PPROMPT,RPAGE,SPAGE
	DB	NUM		;LINES
	DW	LRESP,LPROMPT,RLINES,SLINES
	DB	NUM		;CHARS
	DW	CRESP,CPROMPT,RCHARS,SCHARS
	DB	NUM		;MARGIN
	DW	MRESP,MPROMPT,RMARGIN,SMARGIN
	DB	NUM		;INDENT
	DW	IRESP,IPROMPT,RINDENT,SINDENT
	DB	FLAG		;ADDLF
	DW	ARESP,APROMPT,FLAG?,SADDLF
	DB	FLAG		;FFHARD
	DW	FRESP,FPROMPT,FLAG?,SFFHARD
	DB	FLAG		;TAB
	DW	TRESP,TPROMPT,FLAG?,STAB
	DB	NUM		;XLATE From
	DW	XFRESP,XPROMF,NUMERIC,SXLFROM-2
	DB	NUM		;XLATE To
	DW	XTRESP,XPROMT,NUMERIC,SXLTO-2
;
;	Fake Parameter Table for prompts (QUERY) 
;
FAKETAB	DB	80H		;6.2 @ PARAM
	DB	0		;Type byte
	DB	'F'
FAKERES	DB	0
	DW	VALUE+1		;Destination
	DB	0
;
;
$FF	DB	'$FF',ETX
ONSTR	DB	' ON'
OFFSTR	DB	'OFF'
;
NOPF$	DB	'Forms Filter not Resident',CR
;
ENDPROM	DB	'? ',CURON,ETX
VALUES	DB	'PAGE   = '
SPAGE	DB	' 66',LF,'LINES  = '
SLINES	DB	' 66',LF,'CHARS  = '
SCHARS	DB	'OFF',LF,'MARGIN = '
SMARGIN	DB	'  0',LF,'INDENT = '
SINDENT	DB	'  0',LF,'ADDLF  = '
SADDLF	DB	'OFF',LF,'FFHARD = '
SFFHARD	DB	'OFF',LF,'TAB    = '
STAB	DB	'OFF',LF
DOXLATE	DB	CR,'XLATE  = X',AP
SXLFROM	DB	'00',AP,' => X',AP
SXLTO	DB	'00',AP,LF,CR
;
;
APROMPT	DB	'Add Line Feed after C/R {'
CPROMPT	DB	'Maximum Characters per Line {'
FPROMPT	DB	'Real Form Feeds {'
IPROMPT	DB	'Indent after Wrap-around {'
LPROMPT	DB	'Lines Printed per Page {'
MPROMPT	DB	'Margin Setting {'
PPROMPT	DB	'Physical Page Length {'
TPROMPT	DB	'Tab Expansion {'
XPROMF	DB	'Xlate From {'
XPROMT	DB	'Xlate To {'
;
;
	DB	' '
TEMBUF	DS	5
DUPDA	DS	10
;
	END	START
