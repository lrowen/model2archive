;LBDUMP/ASM - DUMP Command
	TITLE	<DUMP - LS-DOS 6.2>
;
*GET	SVCMAC:3		;SVC Macro equivalents
;
CR	EQU	13
PAR_ERR	EQU	44		;"Parameter Error" #
SINIT	EQU	3000H
EINIT	EQU	SINIT
;
	ORG	2400H
;
DUMP	@@CKBRKC		;Break key down?
	JR	Z,BEGINA	;Ok if not
	LD	HL,-1		;  else abort
	RET
;
BEGINA	LD	DE,FCB1		;Fetch the filespec
	@@FSPEC
	JP	NZ,SPCREQ	;Jump on error
	LD	A,(DE)		;Cannot be a device
	CP	'*'
	JP	Z,SPCREQ	;Quit if device
	@@FLAGS			;Get system flag table
	PUSH	HL		;Save cmdline ptr
	LD	H,(IY+26)	;P/u SVC table MSB
	LD	L,22*2		;  & point to @EXIT entry
	LD	A,(HL)		;Get @EXIT LSB
	INC	L
	LD	H,(HL)		;Get @EXIT MSB
	LD	L,A
	LD	(TPARM+1),HL	;Init transfer to @EXIT
	POP	HL
;
;	Search for parameters
;
	LD	DE,PRMTBL$	;Get the parms
	@@PARAM
	JP	NZ,PRMERR	;Jump on parm error
	LD	HL,(EPARM+1)	;Ck on end > start
	LD	BC,(SPARM+1)
	XOR	A
	SBC	HL,BC
	JP	C,ENLTST	;Jump on start < end
	LD	HL,SINIT	;Pt to lowest possible
	DEC	HL		;Reduce for compare
	SBC	HL,BC		;Ck on start > minimum
	JP	NC,STLT30	;Jump if start < minimum
APARM	LD	BC,0		;ASCII txt or code cim
	LD	A,B
	OR	C
	JR	NZ,DUMPTXT	;Go if ASCII
	LD	DE,NAMFLD	;Get up to a 6-character
	LD	HL,FCB1		;Filename to stuff
	LD	B,6		;As file header
$?1	LD	A,(HL)
	CP	'0'		;Stop on non-alpha
	JR	C,$?3
	CP	'9'+1		;Use if 0-9
	JR	C,$?2
	CP	'A'		;Ck on A-Z
	JR	C,$?3
	CP	'Z'+1
	JR	NC,$?3		;Exit if not A-Z
$?2	LD	(DE),A		;Xfer this char
	INC	HL		;Bump input ptr
	INC	DE		;  & output pointer
	DJNZ	$?1		;Loop 6-chars max
	JR	$?4
$?3	LD	A,' '		;Place blanks to
	LD	(DE),A		;Fill out to 6 chars
	INC	DE
	DJNZ	$?3
$?4	LD	HL,LMFEXT	;Use /LMF extension
	JR	DUMPCIM
DUMPTXT	LD	HL,TXTEXT	;Use /TXT extension
DUMPCIM	LD	DE,FCB1		;Default the EXT
	@@FEXT
LPARM	LD	BC,0		;P/u LRL
	LD	A,B		;Test for > 256
	OR	A		;If hi-order = 0,
	JR	Z,LP1		;Just use lo-order
	DEC	A		;Test hi-order = 1
	JP	NZ,PRMERR
	OR	C		;P/u lo-order
	JP	NZ,PRMERR	;Lo-order must be 0
LP1	OR	C		;Merge lo-order
	LD	B,A
	LD	HL,BUFFER	;Pt to buffer
	@@INIT			;Init the file
	JP	NZ,IOERR	;Quit on init error
;
;	Display the filespec being dumped
;
	LD	BC,(FCB1+6)	;P/u DEC & drive
	LD	DE,FCB2		;Point to FCB area
	PUSH	DE
	@@FNAME			;Fetch the name
	POP	HL
	JP	NZ,IOERR	;Quit on error
	LD	A,20H		;Scan until ETX char
FNLP	INC	HL
	CP	(HL)
	JR	C,FNLP
	LD	(HL),CR		;Replace with CR
	@@LOGOT	DUMP$		;Display "Dumping...
;
	LD	DE,FCB1		;Get dump FCB
	LD	A,(APARM+1)	;Ck if ASCII parm used
	OR	A
	JR	NZ,SPARM	;  and go if so
	LD	A,5		;Name header
	CALL	PUTOUT
	LD	A,6		;Name length
	CALL	PUTOUT
	LD	B,6		;Init loop
	LD	HL,NAMFLD
$?5	LD	A,(HL)
	INC	HL
	CALL	PUTOUT		;Output the filename
	DJNZ	$?5
;
SPARM	LD	HL,SINIT	;P/u starting addr
$?7	PUSH	HL		;Ck on write of
	LD	B,H		;  last byte written
	LD	C,L
EPARM	LD	HL,EINIT-1	;Where to end
	INC	HL
	XOR	A
	SBC	HL,BC
	JR	Z,$?10		;Go if at end
	LD	B,254		;254-byte blocks
	LD	A,H		;A full sector left
	OR	A		;To write?
	JR	NZ,$?8
	LD	A,L
	CP	0FFH
	JR	NC,$?8		;If less than full,
	LD	B,L		;  reset len
$?8	POP	HL
	LD	A,(APARM+1)
	OR	A
	JR	NZ,$?9		;Bypass if TXT
	INC	A		;Init start of block
	CALL	PUTOUT
	LD	A,B		;Get block length
	ADD	A,2		;Add 2 for load address
	CALL	PUTOUT		;  & put it out
	LD	A,L
	CALL	PUTOUT		;Lo-order load address
	LD	A,H
	CALL	PUTOUT		;Hi-order load address
$?9	LD	A,(HL)		;Write a load block
	INC	HL
	CALL	PUTOUT
	DJNZ	$?9
	JR	$?7		;Loop for more
;
$?10	POP	HL		;Stack integrity
	LD	A,(APARM+1)	;No TRAADR if TXT
	OR	A		;  or TRAADR if not TXT
	JR	Z,TRAADR
ETXPARM	LD	BC,3		;P/u etx character
	LD	A,C
	LD	HL,ETXRESP
	BIT	7,(HL)		;Value input means
	JR	NZ,PUTETX	;  put the ETX given
	LD	A,(BC)		;In case string
	BIT	5,(HL)		;String input puts the
	JR	NZ,PUTETX	;  entered char
	BIT	6,(HL)		;Flag input gives ETX=3
	JR	Z,CLSFIL	;  if ETX=on
	LD	A,3
	JR	PUTETX
TRAADR	LD	A,2		;Put traadr header
	CALL	PUTOUT
	LD	A,2
	CALL	PUTOUT
TPARM	LD	HL,$-$		;P/u transfer address
	LD	A,L
	CALL	PUTOUT		;Tra lo-order
	LD	A,H
PUTETX	CALL	PUTOUT		;Tra hi-order or ETX
CLSFIL	@@CLOSE			;Close 'er up
	LD	HL,0
	RET	Z		;Back on no error
	JR	IOERR		;Go on error
;
PUTOUT	LD	C,A		;Xfer the char
	@@PUT			;Test each byte transfer
	RET	Z		;Back if no error
	POP	HL		;Pop the RET addr
	DB	21H		;Skip LD A,## instruction
PRMERR	LD	A,PAR_ERR	;"Parameter Error"
IOERR	LD	L,A		;Error code to HL
	LD	H,0
	OR	0C0H		;Abbrev & return
	LD	C,A
	@@ERROR			;Show the error
	RET
;
;	Internal error routine
;
STLT30	LD	HL,STLT30$
	DB	0DDH
ENLTST	LD	HL,ENLTST$
	DB	0DDH
SPCREQ	LD	HL,SPCREQ$
	@@LOGOT
	LD	HL,-1
	RET
;
ENLTST$	DB	'START or END error ',CR
STLT30$	DB	'Start less than X''3000''',CR
SPCREQ$	DB	'File spec required',CR
LMFEXT	DB	'LMF'
TXTEXT	DB	'TXT'
;
VAL	EQU	80H
SW	EQU	40H
STR	EQU	20H
SGL	EQU	10H
;
PRMTBL$	DB	80H
	DB	VAL!SGL!5,'START',0
	DW	SPARM+1
	DB	VAL!SGL!3,'END',0
	DW	EPARM+1
	DB	VAL!SGL!3,'TRA',0
	DW	TPARM+1
	DB	SW!SGL!5,'ASCII',0
	DW	APARM+1
	DB	VAL!SGL!3,'LRL',0
	DW	LPARM+1
	DB	VAL!3,'ETX',0
ETXRESP	EQU	$-1
	DW	ETXPARM+1
	NOP
;
DUMP$	DB	'Dumping: '	;FCB2 must follow
FCB2	DS	32
NAMFLD	DS	6
FCB1	DS	32
	ORG	$<-8+1<+8
BUFFER	DS	256
LAST	EQU	$-1
;
	END	DUMP
