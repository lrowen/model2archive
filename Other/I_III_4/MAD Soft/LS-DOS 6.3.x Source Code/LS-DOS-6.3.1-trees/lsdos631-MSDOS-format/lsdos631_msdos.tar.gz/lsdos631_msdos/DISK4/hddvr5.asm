;Assemble RS hd driver for 5.1 - 12/12/83
*GET	HDWD5A/ASM:3
*GET	HDWD5B/ASM:3
	END	BEGIN
