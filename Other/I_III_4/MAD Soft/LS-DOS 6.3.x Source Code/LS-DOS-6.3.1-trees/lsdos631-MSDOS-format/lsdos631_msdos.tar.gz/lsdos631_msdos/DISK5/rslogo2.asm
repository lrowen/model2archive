; rslogo2/asm
;
;	ZGRAPH file : RSLOGO2/BIN:3 - 01/28/83
;
;	modified 09/28/83 for Mod II	- kjw
;
	ORG	4*80+CRTBGN$+15
	DC	50,'.'
	ORG	5*80+CRTBGN$+17
	DC	46,'.'
	ORG	6*80+CRTBGN$+20
	DC	40,'.'
	ORG	7*80+CRTBGN$+22
	DC	36,'.'
	ORG	8*80+CRTBGN$+25
	DC	30,'.'
	ORG	9*80+CRTBGN$+27
	DC	26,'.'
	ORG	10*80+CRTBGN$+30
	DC	20,'.'
	ORG	11*80+CRTBGN$+32
	DC	16,'.'
	ORG	12*80+CRTBGN$+32
	DC	16,'.'
	ORG	13*80+CRTBGN$+30
	DC	20,'.'
	ORG	14*80+CRTBGN$+27
	DC	26,'.'
	ORG	15*80+CRTBGN$+25
	DC	30,'.'
	ORG	16*80+CRTBGN$+22
	DC	36,'.'
	ORG	17*80+CRTBGN$+20
	DC	40,'.'
	ORG	18*80+CRTBGN$+17
	DC	46,'.'
	ORG	19*80+CRTBGN$+15
	DC	50,'.'
;
