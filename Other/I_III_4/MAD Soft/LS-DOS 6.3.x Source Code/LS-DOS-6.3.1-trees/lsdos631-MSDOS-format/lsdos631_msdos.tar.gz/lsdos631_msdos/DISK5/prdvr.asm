;PRDVR/ASM - LS-DOS 6.2
	SUBTTL	'<Printer Driver>'
	PAGE	OFF
*MOD
PRPORT	EQU	0F8H
;
;	PR driver entry point
;	It passes X'00'-X'FF'
;	Unless INTL version
;
PRDVR	JR	PRBGN		;Branch around linkage
	DW	PREND		;Last byte used
	DB	3,'$PR'
	DW	PRDCB$		;Pointer to its DCB
	DW	0		;Reserved
;
;	Driver code
;
PRBGN	JR	Z,$?2		;Go if output
	JR	C,$?1		;Go if input req
;
;	Character CTL request
;
	LD	A,C		;If CTL 0, return
	OR	A		;  status else
	JR	Z,$?4		;  treat as a Get
;
;	Character GET request
;
$?1	OR	0FFH		;Set nz
	CPL			;  & A=0	to show
	RET			;  no char available
;
;	Character PUT request
;
$?2	LD	DE,0FFFFH	;Check status 2000 times
$?2A	CALL	$?4		;PR ready?
	JR	Z,$?3		;Go if so
;
;	Ten second timout delay loop
;
	PUSH	BC		;Printer was not ready
	LD	BC,8
	CALL	PAUSE@		;Delay a bit
	POP	BC
	IF	@BLD631
@PRTIMO:DEC	DE		;<631>SYSTEM cmd patches this addr
	ELSE
	DEC	DE		;Time up?
	ENDIF
	LD	A,D
	OR	E
	JR	NZ,$?2A		;Nope, continue check
	LD	A,8		;Device not avail...
	OR	A		;Set NZ condition
	RET
$?3	EQU	$
;
	IF	@INTL
	LD	A,(IFLAG$)
	BIT	6,A		;Special DMP PR?
	ENDIF
;
	LD	A,C
;
	IF	@INTL
	JR	Z,PVAL3
	CP	0C0H		;Values C0-FF (-20H)
	JR	C,PVAL2		;Go if less
	SUB	20H		;Shift to European chars
	JR	PVAL3
PVAL2	CP	0A0H		;A0-BF (+40H)
	JR	C,PVAL3		;Go if less
	ADD	A,40H		;Shift to graphics
	ENDIF
;
PVAL3	OUT	(PRPORT),A	;Put out char
;
	IF	@INTL
	LD	A,C		;Restore original
	CP	A		;Set Z
	ENDIF
;
	RET
;
$?4	IN	A,(PRPORT)	;Scan PR status
	AND	0F0H		;Mask unused positions
	CP	30H		;PR ready?
	RET			;Return with answer
PREND	EQU	$-1
